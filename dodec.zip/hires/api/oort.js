
/*

  oort.js
  Object Oriented Ray Tracing stuff
  Dave Wellsted, NyteOwl Computer Software
  2018-JAN-06

  Methods:
  
    ill2, ill3, sign
    orient2, orient3, overlap 
    ilpl, i3pl, refpp, distpp
    mindist, plane, commonline
    m3identity, m3transpose, m3det, m3inverse
  
*/

const OORT = {
  // Find POI (in v) for two lines
  // v1+mu*v2 and v3+lambda*v4
  // Returns true for success
  ill2: function(v1,v2,v3,v4,v) {
    let mu, delta;
    delta=v2.x*v4.y-v2.y*v4.x;
    if (Math.abs(delta)<Constants.TINY) {
      return false; // Lines are parallel
    }
    mu=((v3.x-v1.x)*v4.y-((v3.y-v1.y)*v4.x))/delta;
    v.x=v1.x+mu*v2.x;
    v.y=v1.y+mu*v2.y;
    return true;
  },
  // Calculate POI for two 3D lines
  // Lines: b1+mu*d1, b2+lambda*d2
  // Returns true for intersection found
  // Members p, mu, and lambda in result
  ill3: function(b1,d1,b2,d2,result) {
    const bb1=[], bb2=[], dd1=[], dd2=[];
    let id, delta, value, factor1, factor2, lambda, mu;
    let i, i0, i1, i2;
    Vec.Copy(b1,bb1);
    Vec.Copy(b2,bb2);
    Vec.Copy(d1,dd1);
    Vec.Copy(d2,dd2);
    for (i=0; i<3; i++) {
      i0=i; i1=(i+1)%3;
      delta=dd1[i0]*dd2[i1]-dd1[i1]*dd2[i0];
      if (Math.abs(delta) > Vec.TINY) {
        id = 1 / delta;
        factor1=bb2[i0]-bb1[i0];
        factor2=bb2[i1]-bb1[i1];
        mu=(dd2[i1]*factor1 - dd2[i0]*factor2)*id;
        lambda=(dd1[i1]*factor1 - dd1[i0]*factor2)*id;
        i2=(i1+1)%3;
        value=bb1[i2]+mu*dd1[i2]-bb2[i2]-lambda*dd2[i2];
        if (Math.abs(value) <= Vec.TINY) {
          result.mu = mu;
          result.lambda = lambda;
          result.p = [];
          Vec.AddS(result.mu,d1,b1,result.p);
          return true;  // success
        }
      }      
    }
    return false; // No intersection
  },
  // Algebraic sign [-1,0,+1]
  sign: function(r) {
    if (r > Constants.TINY) {
      return 1;
    }
    if (r < -Constants.TINY) {
      return -1;
    }
    return 0;
  },
  // Determine 2D polygon orientation
  // p0, p1, p2 -- polygon vertices
  // Returns:
  // +1 for CW
  // -1 for CCW
  // 0 for degenerate
  orient2: function(p0,p1,p2) {
    const d1 = {}, d2 = {}
    d1.x=p1.x-p0.x; d1.y=p1.y-p0.y;
    d2.x=p2.x-p1.x; d2.y=p2.y-p1.y;
    return OORT.sign(d1.x*d2.y-d1.y*d2.x);
  },
  // Determine 3D polygon orientation
  // as viewed from point e
  // p0, p1, p2 -- polygon vertices
  // Returns:
  // +1 for CW
  // -1 for CCW
  //  0 for degenerate
  orient3: function(p0,p1,p2,e) {
    const d1=[], d2=[], d1xd2 = [], v = [];
    Vec.Sub(p1,p0,d1);
    Vec.Sub(p2,p1,d2);
    Vec.Cross(d1,d2,d1xd2);
    Vec.Sub(e,p1,v);
    return OORT.sign(Vec.Dot(d1xd2,v));
  },
  // Intersection of two 2D polygons
  // Clips polygon a to polygon b, resulting in c.
  // Returns false for no intersection (fully clipped).
  // Orientation is as from orient2 on both a AND b.
  overlap: function(apoly,bpoly,cpoly,orientation) {
    let numa = apoly.length;
    let numb = bpoly.length;
    let numc;
    let i, j, index1, index2, l1, l2, cnumdash;
    const f = [[],[]];
    let end1 = {}, end2 = {}, v1 = {}, v2 = {};
    let ca, cb, cc, fv1, fv2, absfv1, absfv2, delta;
    // Copy apoly into f[0] array
    l1=0; numc=numa;
    for (i=0; i<numc; i++) {
      f[l1][i] = Vector2Factory.createFrom(apoly[i]);
    }
    // Clip feasible poly. End points are end1, end2.
    end1 = bpoly[numb-1];
    for (i=0; i<numb; i++) {
      l2 = 1-l1;
      end2 = bpoly[i];
      ca = end2.x - end1.x;
      cb = end1.y - end2.y;
      cc = -end1.x*cb - end1.y*ca;
      v1 = Vector2Factory.createFrom(f[l1][numc-1]);
      fv1 = ca*v1.y + cb*v1.x + cc
      absfv1 = Math.abs(fv1);
      if (absfv1 < Constants.TINY) {
        index1 = 0;
      }
      else {
        index1 = OORT.sign(fv1) * orientation;
        numcdash = 0;
        for (j=0; j<numc; j++) {
          v2 = Vector2Factory.createFrom(f[l1][j]);
          fv2 = ca*v2.y + cb*v2.x + cc;
          absfv2 = Math.abs(fv2);
          if (absfv2 < Constants.TINY) {
            index2 = 0;
          }
          else {
            index2 = OORT.sign(fv2) * orientation;
          }
          if (index1 >= 0) {
            f[l2][numcdash] = v1;
            numcdash = numcdash + 1;
          }
          if ((index1!==0) && (index1!==index2) && (index2!==0)) {
            delta = absfv1 + absfv2;
            f[l2][numcdash] = {}
            f[l2][numcdash].x = (absfv2*v1.x + absfv1*v2.x)/delta;
            f[l2][numcdash].y = (absfv2*v1.y + absfv1*v2.y)/delta;
            numcdash = numcdash + 1;
          }
          fv1 = fv2;
          absfv1 = absfv2;
          index1 = index2;
          v1 = v2;
        }
        if (numcdash<3) {
          return false; // degenerate
        }
        else {
          numc = numcdash;
          l1 = l2;
          end1 = end2;
        }
      }
    }
    // Copy resulting polygon to o/p
    for (i=0; i<numc; i++) {
      cpoly[i] = Vector2Factory.createFrom(f[l1][i]);
    }
    return true;
  },
  // Calculate POI between line and plane
  // line: b+mu*d, plane: k = n dot v
  // Return true for success
  // Members p and mu set in result
  ilpl: function(b,d,n,k,result) {
    const dotprod1 = Vec.Dot(d,n);
    if (Math.abs(dotprod1) < Vec.TINY) {
      return false; // line parallel to plane
    }
    const dotprod2 = Vec.Dot(b,n);
    result.mu = (k-dotprod2)/dotprod1;
    result.p = [];
    Vec.AddS(result.mu,d,b,result.p);
    return true;
  },
  // Calculate reflection point p' given
  // point p and plane: k = n dot v
  // Members p and mu set in result
  refpp: function(p,n,k,result) {
    const r = {};
    OORT.ilpl(p,n,n,k,r);
    result.mu = r.mu;
    result.p = [];
    Vec.AddS(2*result.mu,n,p,result.p);
  },
  // Calculate point to plane distance
  // point p and plane: k = n dot v
  // Returns dist
  distpp: function(p,n,k) {
    const t = Vec.Len(n);
    const d = Vec.Dot(p,n);
    return (Math.abs(k-d)/t);
  },
  // Minimum distance between two 3D lines
  // Lines: a+mu*c, b+lambda*d
  mindist: function(a,c,b,d) {
    const aminusb=[], aminuse=[], p=[];
    let lambda, pmod;
    Vec.Cross(c,d,p);
    pmod=Vec.Len(p);
    Vec.Sub(a,b,aminusb);
    if (pmod > Vec.TINY) {
      return Math.abs(Vec.Dot(p,aminusb))/pmod;
    }
    lambda = Vec.Dot(c,aminusb)/Vec.Dot(c,d);
    Vec.AddS(-lambda,d,aminusb,aminuse);
    return Vec.Len(aminuse);
  },
  // Calculate plane given 3 points
  // Members n and k in result
  plane: function(p1,p2,p3,result) {
    const d1=[], d2=[];
    Vec.Sub(p2,p1,d1);
    Vec.Sub(p3,p2,d2);
    result.n=[];
    Vec.Cross(d1,d2,result.n);
    result.k=Vec.Dot(result.n,p1);
  },
  // Return 3x3 identity matrix
  m3identity: function() {
    return [
      [1,0,0],
      [0,1,0],
      [0,0,1]
    ];
  },
  // Return transpose of 3x3 matrix
  m3transpose: function(A) {
    return [
      [A[0][0], A[1][0], A[2][0]],
      [A[0][1], A[1][1], A[2][1]],
      [A[0][2], A[1][2], A[2][2]]
    ];
  },
  // Return determinant of 3x3 matrix
  m3det: function(A) {
    return (
      A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])+
      A[0][1]*(A[1][2]*A[2][0]-A[1][0]*A[2][2])+
      A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0])
    );
  },
  // Return inverse of 3x3 matrix
  m3inverse: function(A) {
    const det = OORT.m3det(A);
    if (Math.abs(det) < Math.TINY) {
      throw 'Singular matrix';
    }
    const AINV = [[],[],[]];
    const invdet = 1/det;
    let adj, i, i1, i2, j, j1, j2;
    for (i=0; i<3; i++) {
      i1 = (i+1)%3;
      i2 = (i1+1)%3;
      for (j=0; j<3; j++) {
        j1 = (j+1)%3;
        j2 = (j1+1)%3;
        adj = (A[i1][j1]*A[i2][j2] - A[i1][j2]*A[i2][j1]);
        AINV[j][i] = adj*invdet;
      }
    }
    return AINV;
  },
  // Intersection point for 3 planes
  // Planes: k = n dot v
  // Member v in result
  i3pl: function(n1,k1,n2,k2,n3,k3,result) {
    const N=[[],[],[]];
    Vec.Copy(n1,N[0]);
    Vec.Copy(n2,N[1]);
    Vec.Copy(n3,N[2]);
    const NINV = OORT.m3inverse(N);
    result.v = [];
    result.v[0] = NINV[0][0]*k1+NINV[0][1]*k2+NINV[0][2]*k3;
    result.v[1] = NINV[1][0]*k1+NINV[1][1]*k2+NINV[1][2]*k3;
    result.v[2] = NINV[2][0]*k1+NINV[2][1]*k2+NINV[2][2]*k3;
  },
  // Line intersection of two planes
  // Planes: k = n dot v
  // Members b and d in result
  commonline: function(n1,k1,n2,k2,result) {
    const N=[[],[],[]];
    Vec.Copy(n1,N[0]);
    Vec.Copy(n2,N[1]);
    Vec.Cross(n1,n2,N[2]);
    result.b = [];
    result.d = [];
    Vec.Copy(N[2],result.d);
    const NINV = OORT.m3inverse(N);
    result.b[0]=k1*NINV[0][0]+k2*NINV[0][1];
    result.b[1]=k1*NINV[1][0]+k2*NINV[1][1];
    result.b[2]=k1*NINV[2][0]+k2*NINV[2][1];
  }
}

