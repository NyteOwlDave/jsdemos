
/*

  grid.js -- Grid demo
  Dave Wellsted, NyteOwl Computer Software
  2018-JAN-06
  
*/

const Grid = {
  // View matrix
  Q: Mtx.identity(),
  // Prepare view matrix Q
  look: function(eye,at,up) {
    let A = Mtx.lookat(eye,at,up);
    let B = Mtx.translate(-eye[0],-eye[1],-eye[2]);
    Grid.Q = Mtx.cat(A,B);
  },
  // Function to be plotted
  // y = f(x,z)
  f: function(x,z) {
    const t = Math.sqrt(x*x + z*z);
    if (Math.abs(t) < Vec.TINY) {
      return 4;
    }
    return (4*Math.sin(t)/t);
  },
  // Draw a trianglular patch
  tri: function(canvas,v0,v1,v2) {
    const poly = [
      Vector2Factory.createFrom(v0),
      Vector2Factory.createFrom(v1),
      Vector2Factory.createFrom(v2)
    ];
    Grid.drawPolygon(canvas,poly);
  },
  // Draw a quadrangular patch
  quad: function(canvas,v0,v1,v3,v2) {
    const poly = [
      Vector2Factory.createFrom(v0),
      Vector2Factory.createFrom(v1),
      Vector2Factory.createFrom(v3),
      Vector2Factory.createFrom(v2)
    ];
    Grid.drawPolygon(canvas,poly);
  },
  // Draw a patch (tri or quad)
  patch: function(canvas,v0,v1,v2,v3) {
    let denom, mu;
    let v4;
    denom = (v1.x-v0.x)*(v3.y-v2.y) - (v1.y-v0.y)*(v3.x-v2.x);
    if (Math.abs(denom) > Vec.TINY) {
      mu = ((v2.x-v0.x)*(v3.y-v2.y) - (v2.y-v0.y)*(v3.x-v2.x))/denom;
      if ((mu>=0)&&(mu<=1)) {
        const x = (1-mu)*v0.x + mu*v1.x;
        const y = (1-mu)*v0.y + mu*v1.y;
        v4 = new Vector2(x,y);
        Grid.tri(canvas,v0,v2,v4);
        Grid.tri(canvas,v1,v3,v4);
        return;
      }
    }
    denom = (v2.x-v0.x)*(v3.y-v1.y) - (v2.y-v0.y)*(v3.x-v1.x);
    if (Math.abs(denom) > Vec.TINY) {
      mu = ((v1.x-v0.x)*(v3.y-v1.y) - (v1.y-v0.y)*(v3.x-v1.x))/denom;
      if ((mu>=0)&&(mu<=1)) {
        const x = (1-mu)*v0.x + mu*v2.x;
        const y = (1-mu)*v0.y + mu*v2.y;
        v4 = new Vector2(x,y);
        Grid.tri(canvas,v0,v1,v4);
        Grid.tri(canvas,v2,v3,v4);
        return;
      }
    }
    Grid.quad(canvas,v0,v1,v3,v2);
    return;
  },
  // Draw the grid (plot)
  drawGrid: function(canvas,xmin,xmax,nx,zmin,zmax,nz) {
    const Q = Grid.Q;
    const v = [[],[]];
    let xi,xstep,yij;
    let zj,zstep;
    let i,j,x,y;
    xstep = (xmax-xmin)/nx;
    zstep = (zmax-zmin)/nz;
    xi = xmin; zj = zmin;
    for (i=0; i<=nx; i++) {
      yij = Grid.f(xi,zj);
      x = Q[0][0]*xi + Q[0][1]*yij + Q[0][2]*zj;
      y = Q[1][0]*xi + Q[1][1]*yij + Q[1][2]*zj;
      v[0][i] = new Vector2(x,y);
      xi = xi + xstep;
    }
    for (j=0; j<nx; j++) {
      xi=xmin; zj=zj+zstep;
      for (i=0; i<=nx; i++) {
        yij = Grid.f(xi,zj);
        x = Q[0][0]*xi + Q[0][1]*yij + Q[0][2]*zj;
        y = Q[1][0]*xi + Q[1][1]*yij + Q[1][2]*zj;
        v[1][i] = new Vector2(x,y);
        xi = xi + xstep;
      }
      for (i=0; i<nx; i++) {
        Grid.patch(canvas,v[0][i],v[0][i+1],v[1][i],v[1][i+1]);
      }
      for (i=0; i<=nx; i++) {
        v[0][i] = v[1][i];
      }
    }
  },
  // Transform polygon to screen space and draw it
  drawPolygon: function(canvas,poly) {
    const w = canvas.width;
    const h = canvas.height;
    const wh = Math.floor(w/2);
    const hh = Math.floor(h/2);
    const scale = wh/20;
    function xform(vtx) {
      return {
        x: wh + vtx.x*scale,
        y: hh - vtx.y*scale
      }
    }
    const gfx = canvas.getContext('2d');
    let i,v;
    gfx.strokeStyle = 'white';
    gfx.fillStyle = 'gray';
    gfx.beginPath();
    v = xform(poly[0]);
    gfx.moveTo(v.x,v.y);
    for (i=1; i<poly.length; i++) {
      v = xform(poly[i]);
      gfx.lineTo(v.x,v.y);
      gfx.stroke();
    }
    gfx.closePath();
    gfx.fill();    
  }
}

