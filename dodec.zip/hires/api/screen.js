
/*

  screen.js -- Screen functions
  Dave Wellsted, NyteOwl Computer Software
  2017-DEC-31
  
*/

const Screen = {
  canvas: null,     // HTML5 canvas element
  w: 0,             // Canvas width
  h: 0,             // Canvas height
  scale: 1,         // Scaling factor
  xOffset: 0,       // Horizontal center
  yOffset: 0,       // Vertical center
  fov: 90,          // Field of view (degrees)
  // Initialize the screen object
  init: function(canvas, fov) {
    Screen.canvas = canvas;
    Screen.fov = fov;
    const w = canvas.width;
    const h = canvas.height;
    Screen.w = w;
    Screen.h = h;
    Screen.xOffset = Math.floor(w/2);
    Screen.yOffset = Math.floor(h/2);
    const r = Vec.deg2rad(fov/2);
    Screen.scale = Screen.xOffset / Math.tan(r);
  },
  // Convert 3D view coords to 2D screen coords
  mapToScreen: function(vec3) {
    const k = Screen.scale / vec3[2];
    const x = Screen.xOffset + vec3[0]*k;
    const y = Screen.yOffset - vec3[1]*k;
    return new Vector2(x,y);
  },
  // Convert 2D screen coords to 3D view coords
  mapToView: function(vec2) {
    const k = 1 / Screen.scale;
    const x = k*(vec2.x - Screen.xOffset);
    const y = k*(vec2.y + Screen.yOffset);
    return [x, y, 1];
  },
  // Clear the screen
  clear: function() {
    Grafix.fill(Screen.canvas,'black');
  },
  // Capture the screen as image data
  capture: function() {
    const canvas = Screen.canvas;
    const w = canvas.width;
    const h = canvas.height;
    const gfx = canvas.getContext('2d');
    const img = new ImageData(w,h);
    return gfx.getImageData(0,0,w,h);
  }
}

