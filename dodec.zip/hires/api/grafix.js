
/*

  grafix.js -- Misc. graphics functions
  Dave Wellsted, NyteOwl Computer Software
  2018-JAN-06
  
*/

// Project.register('grafix.js')

// Requires: vec.js, vector2.js, oort.js

const Grafix = {
  // Fill canvas will a color
  fill: function(canvas,color) {
    const w = canvas.width
    const h = canvas.height
    const gfx = canvas.getContext('2d')
    gfx.fillStyle = color
    gfx.fillRect(0,0,w,h)
  },
  // Draw a spiderweb (circular graph)
  spider: function(canvas,color,stepSize) {
    const w = canvas.width
    const h = canvas.height
    const xc = w/2
    const yc = h/2
    const gfx = canvas.getContext('2d')
    gfx.strokeStyle = color
    const rho = 0.5 * Math.sqrt(w*w + h*h)
    function line(n) {
      if (n < 0) return
      const theta = n*Math.PI/12
      const dx = rho*Math.cos(theta)
      const dy = rho*Math.sin(theta)
      gfx.beginPath()
      gfx.moveTo(xc+dx,yc+dy)
      gfx.lineTo(xc-dx,yc-dy)
      gfx.stroke()
      line(n-1)
    }
    line(11)
    function circle(n) {
      if (n < 1) return
      const r = n*stepSize
      gfx.beginPath()
      gfx.ellipse(xc,yc,r,r,0,0,2*Math.PI)
      gfx.stroke()
      circle(n-1)
    }
    circle(Math.floor(rho/stepSize))
  },
  // Draw the polygon whose vertices
  // are stored in array p. Solid white.
  drawPolygon: function(canvas,p) {
    Grafix.drawPolygon2(canvas,p,1,'white');
  },
  // Draw the polygon whose vertices
  // are stored in array p. Custom
  // line width and color.
  drawPolygon2: function(canvas,p,width,color) {
    const gfx = canvas.getContext('2d');
    gfx.strokeStyle = color;
    gfx.lineWidth = width;
    gfx.beginPath();
    gfx.moveTo(p[0].x,p[0].y);
    const n = p.length-1;
    let i;
    for (i=1; i<=n; i++) {
      gfx.lineTo(p[i].x,p[i].y);
    }
    gfx.closePath();
    gfx.stroke();
  },
  // Fill the polygon whose vertices
  // are stored in array p. Solid white.
  fillPolygon: function(canvas,p) {
    Grafix.fillPolygon2(canvas,p,'white');
  },
  // Fill the polygon whose vertices
  // are stored in array p. Custom
  // color.
  fillPolygon2: function(canvas,p,color) {
    const gfx = canvas.getContext('2d');
    gfx.fillStyle = color;
    gfx.beginPath();
    gfx.moveTo(p[0].x,p[0].y);
    const n = p.length-1;
    let i;
    for (i=1; i<=n; i++) {
      gfx.lineTo(p[i].x,p[i].y);
    }
    gfx.closePath();
    gfx.fill();
  },
  // Draw cross hatch marks
  crossHatch: function(canvas,p,b,d,dist) {
    Grafix.hatch(canvas,p,b,d,dist);
    const t = d.x;
    d.x = -d.y;
    d.y = t;
    Grafix.hatch(canvas,p,b,d,dist);
  },
  // Draw single hatch marks
  // p    polygon vertex array
  // b    anchor point
  // d    direction vector
  // dist distance between lines
  hatch: function(canvas,p,b,d,dist) {
    let i,isec,j,lasti,n,nmin,nmax
    let nint,nnp,npoint=[],m=p.length
    let alpha,c,cmax,cmid,cmin,dmod
    let mu1,mu2,mu=[]
    let e={},inter={},p1={},p2={},q={},s={}
    const gfx = canvas.getContext('2d')
    gfx.strokeStyle='white';
    // Find cmin, cmid and cmax
    cmid=d.x*b.y - d.y*b.x;
    cmin= Constants.HUGE;
    cmax=-Constants.HUGE;
    for (i=0; i<m; i++) {
      c=d.x*p[i].y - d.y*p[i].x;
      if (c<cmin) cmin=c;
      if (c>cmax) cmax=c;
    }
    // Construct vector s
    dmod=d.length();
    s.x=-dist/dmod*d.y;
    s.y= dist/dmod*d.x;
    // Calculate nmin and nmax
    nmin=Math.floor((cmin-cmid)/(dist*dmod)+0.9999);
    nmax=Math.floor((cmax-cmid)/(dist*dmod));
    // Hatch the polygon
    for (n=nmin; n<=nmax; n++) {
      // Find base vector q for this line
      q.x=b.x+n*s.x;
      q.y=b.y+n*s.y;
      // Find nint (intersection)
      nint=0; lasti=m-1;
      for (i=0; i<m; i++) {
        e.x=p[i].x - p[lasti].x;
        e.y=p[i].y - p[lasti].y;
        isec = OORT.ill2(p[lasti],e,q,d,inter);
        if (isec) {
          alpha=(inter.x-p[lasti].x)/e.x;
          if ((alpha>=0)&&(alpha<=1)) {
            nint=nint+1;
            npoint[nint]=nint;
            mu[nint]=(inter.x-q.x)/d.x;
          }
        }
        lasti=i;
      }
      // Sort mu values
      for (i=1; i<nint; i++) {
        for (j=i+1; j<=nint; j++) {
          if (mu[npoint[i]] < mu[npoint[j]]) {
            nnp=npoint[i];
            npoint[i]=npoint[j];
            npoint[j]=nnp;
          }
        }
      }
      // Draw hatch lines
      gfx.beginPath();
      i=1;
      while (i<nint) {
        mu1=mu[npoint[i]];
        mu2=mu[npoint[i+1]];
        p1.x=q.x+mu1*d.x; p1.y=q.y+mu1*d.y;
        p2.x=q.x+mu2*d.x; p2.y=q.y+mu2*d.y;
        gfx.moveTo(p1.x,p1.y);
        gfx.lineTo(p2.x,p2.y);
        gfx.stroke();
        i+=2;
      }
    }
  },
}

