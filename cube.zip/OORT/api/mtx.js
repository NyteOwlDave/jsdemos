
/*

  mtx.js -- Matrix 4x4 Math
  Dave Wellsted
  NyteOwl Computer Software
  Updated: 2017-DEC-31

  Methods:

    zero, identity
    rotate, scale, translate, transform
    rotateX, rotateY, rotateZ, rotate
    quat, lookat
    luindx, ludcmp, lubksb
    copy, clone, transpose, inverse
    cat, transVector, transNormal
    composeVector, composeMatrix
    composeRotate, composeScale, composeTranslate
    composeRotateX, composeRotateY, composeRotateZ
    report
  
*/

// Global 4x4 Matrix object
Mtx = {}

// Return empty matrix
Mtx.zero = function() {
  return [
    [ 0, 0, 0, 0],
    [ 0, 0, 0, 0],
    [ 0, 0, 0, 0],
    [ 0, 0, 0, 0]
  ];
}

// Return identity matrix
Mtx.identity = function() {
  return [
    [ 1, 0, 0, 0],
    [ 0, 1, 0, 0],
    [ 0, 0, 1, 0],
    [ 0, 0, 0, 1]
  ];
}

// Return x,y,z scaling matrix
Mtx.scale = function(sx,sy,sz) {
  return [
    [sx, 0, 0, 0],
    [ 0,sy, 0, 0],
    [ 0, 0,sz, 0],
    [ 0, 0, 0, 1]
  ];
}

// Return x,y,z translate matrix
Mtx.translate = function(tx,ty,tz) {
  return [
    [ 1, 0, 0,tx],
    [ 0, 1, 0,ty],
    [ 0, 0, 1,tz],
    [ 0, 0, 0, 1]
  ];
}

// Return x rotate matrix
Mtx.rotateX = function(angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return [
    [ 1, 0, 0, 0],
    [ 0, c,-s, 0],
    [ 0, s, c, 0],
    [ 0, 0, 0, 1]
  ];
}

// Return y rotate matrix
Mtx.rotateY = function(angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return [
    [ c, 0, s, 0],
    [ 0, 1, 0, 0],
    [-s, 0, c, 0],
    [ 0, 0, 0, 1]
  ];
}

// Return z rotate matrix
Mtx.rotateZ = function(angle) {
  const c = Math.cos(angle);
  const s = Math.sin(angle);
  return [
    [ c,-s, 0, 0],
    [ s, c, 0, 0],
    [ 0, 0, 1, 0],
    [ 0, 0, 0, 1]
  ];
}

// Return x,y,z rotate matrix
Mtx.rotate = function(ax,ay,az) {
  const sx = Math.sin(ax);
  const cx = Math.cos(ax);
  const sy = Math.sin(ay);
  const cy = Math.cos(ay);
  const sz = Math.sin(az);
  const cz = Math.cos(az);
  return [
    [
      cy * cz,
      sx * sy * cz - cx * sz,
      cx * sy * cz + sx * sz,
      0
    ],
    [
      cy * sz,
      sx * sy * sz + cx * cz,
      cx * sy * sz - sx * cz,
      0
    ],
    [
      -sy,
      sx * cy,
      cx * cy,
      0
    ],
    [ 0, 0, 0, 1]
  ];
}

Mtx.rotateDebug = function(ax,ay,az) {
  const A = Mtx.rotateX(ax);
  const B = Mtx.rotateY(ay);
  const C = Mtx.rotateZ(az);
  return Mtx.cat(C,Mtx.cat(B,A));
}

// Return quaternion matrix
Mtx.quat = function(x,y,z,angle) {
   const c = Math.cos( angle );
   const s = Math.sin( angle );
   const cc = 1 - c;
   const v = [x,y,z];
   Vec.Normalize(v);
   x = v[0];
   y = v[1];
   z = v[2];
   return [
     [(cc*x*x)+c,(cc*x*y)+(z*s),(cc*x*z)-(y*s),0],
     [(cc*x*y)-(z*s),(cc*y*y)+c,(cc*z*y)+(x*s),0],
     [(cc*x*z)+(y*s),(cc*y*z)-(x*s),(cc*z*z)+c,0],
     [0,0,0,1]
   ];
}

// Return viewpoint matrix
Mtx.lookat = (function() {
  let x, y, z;
  return function lookAt(eye, target, up) {
    if (x===undefined) {
      x = [0,0,0];
      y = [0,0,0];
      z = [0,0,0];
    }
    Vec.Sub(eye,target,z);
    if (Vec.LenSqr(z)<Vec.TINY) {
      // eye and target are in the same position
      z[2] = 1;
    }
    Vec.Normalize(z);
    Vec.Cross(up,z,x);
    if (Vec.LenSqr(x)<Vec.TINY) {
      // eye and target are in the same vertical
      z[2] += 0.0001;
      Vec.Cross(up,z,x);
    }
    Vec.Normalize(x);
    Vec.Cross(z,x,y);
    return [
      [ x[0], x[1], x[2], 0 ],
      [ y[0], y[1], y[2], 0 ],
      [ z[0], z[1], z[2], 0 ],
      [ 0, 0, 0, 1 ]
    ];
  };
})();

// Return transformation matrix (alternate)
Mtx.transform = function(ax,ay,az,mx,my,mz,tx,ty,tz) {
  const sx = Math.sin(ax);
  const cx = Math.cos(ax);
  const sy = Math.sin(ay);
  const cy = Math.cos(ay);
  const sz = Math.sin(az);
  const cz = Math.cos(az);
  return [
    [
      mx * (cy * cz),
      my * (sx * sy * cz - cx * sz),
      mz * (cx * sy * cz + sx * sz),
      tx
    ],
    [
      mx * (cy * sz),
      my * (sx * sy * sz + cx * cz),
      mz * (cx * sy * sz - sx * cz),
      ty
    ],
    [
      mx * (-sy),
      my * (sx * cy),
      mz * (cx * cy),
      tz
    ],
    [ 0, 0, 0, 1]
  ];
}

// Concatenate two matrices A x B => C (alternate #1)
Mtx.cat = function(a,b) {
  const m = Mtx.zero();
  let i, j, k;
  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      for (k=0; k<4; k++) {
        m[i][j] += a[i][k] * b[k][j];
      }
    }
  }
  return m;
}

// Creat index buffer for LU operations
Mtx.luindx = function() {
  return (new Int32Array(4));
}

// LU decompostion
Mtx.ludcmp = function(a,indx) {
  const vv = [0,0,0,0]; // implicit scale for each row
  let big, dum, sum, tmp;
  let i, imax = 0;
  let j, k;
  let d = 1.0;
  for (i = 0; i < 4; i++) {
    big = 0.0;
    for (j = 0; j < 4; j++) {
      if ((tmp = Math.abs(a[i][j])) > big) {
        big = tmp;
      }
    }
    if (big == 0.0) {
      throw 'Mtx.ludcmp(): singular matrix found';
    }
    vv[i] = 1.0/big;
  }
  for (j = 0; j < 4; j++) {
    for (i = 0; i < j; i++) {
      sum = a[i][j];
      for (k = 0; k < i; k++) {
        sum -= a[i][k] * a[k][j];
      }
      a[i][j] = sum;
    }
    big = 0.0;
    for (i = j; i < 4; i++) {
      sum = a[i][j];
      for (k = 0; k < j; k++) {
        sum -= a[i][k]*a[k][j];
      }
      a[i][j] = sum;
      if ((dum = vv[i] * Math.abs(sum)) >= big) {
        big = dum;
        imax = i;
      }
    }
    if (j != imax) {
      for (k = 0; k < 4; k++) {
        dum = a[imax][k];
        a[imax][k] = a[j][k];
        a[j][k] = dum;
      }
      d = -d;
      vv[imax] = vv[j];
    }
    indx[j] = imax;
    if (a[j][j] == 0.0) {
      a[j][j] = 1.0e-20;
    }
    if (j != 3) {
      dum = 1.0/a[j][j];
      for (i = j+1; i < 4; i++) {
        a[i][j] *= dum;
      }
    }
  }
  return d;
}

// LU back substitution
Mtx.lubksb = function(a,indx,b) {
  let i, j, ii=-1, ip;
  let sum;
  for (i = 0; i < 4; i++) {
    ip = indx[i];
    sum = b[ip];
    b[ip] = b[i];
    if (ii>=0) {
      for (j = ii; j <= i-1; j++) {
        sum -= a[i][j] * b[j];
      }
    }
    else if (sum != 0.0) {
      ii = i;
    }
    b[i] = sum;
  }
  for (i = 3;i >= 0;i--) {
    sum = b[i];
    for (j = i+1;j < 4;j++) {
      sum -= a[i][j] * b[j];
    }
    b[i] = sum/a[i][i];
  }
}

// Return cloned matrix
Mtx.clone = function(m) {
  return [
    [m[0][0], m[0][1], m[0][2], m[0][3]],
    [m[1][0], m[1][1], m[1][2], m[1][3]],
    [m[2][0], m[2][1], m[2][2], m[2][3]],
    [m[3][0], m[3][1], m[3][2], m[3][3]]
  ];
}

// Return transpose matrix
Mtx.transpose = function(m) {
  return [
    [m[0][0], m[1][0], m[2][0], m[3][0]],
    [m[0][1], m[1][1], m[2][1], m[3][1]],
    [m[0][2], m[1][2], m[2][2], m[3][2]],
    [m[0][3], m[1][3], m[2][3], m[3][3]]
  ];
}

// Return inverse matrix
Mtx.inverse = function(m) {
  const n = Mtx.clone(m);             // clone original matrix
  const y = Mtx.zero();               // prep an o/p matrix
  const indx = Mtx.luindx();
  let i, j;
  let col = [0,0,0,0];
  let d = Mtx.ludcmp(n, indx);        // matrix lu decomposition
  for (j = 0; j < 4; j++) {          // matrix inversion
    for (i = 0; i < 4; i++) {
      col[i] = 0.0;
    }
    col[j] = 1.0;
    Mtx.lubksb(n, indx, col);
    for (i = 0;i < 4;i++) {
      y[i][j] = col[i];
    }
  }
  return y;
}

// Copy one matrix to another
Mtx.copy = function(m,o) {
  let i, j;
  for (j = 0; j < 4; j++) {          // matrix inversion
    for (i = 0; i < 4; i++) {
      o[j][i] = m[j][i];
    }
  }
}

// Return transformed vector
Mtx.transVector = function(m,v) {
  let u = [
    (
      m[0][0]*v[0] +
      m[0][1]*v[1] +
      m[0][2]*v[2] +
      m[0][3]
    ),
    (
      m[1][0]*v[0] +
      m[1][1]*v[1] +
      m[1][2]*v[2] +
      m[1][3]
    ),
    (
      m[2][0]*v[0] +
      m[2][1]*v[1] +
      m[2][2]*v[2] +
      m[2][3]
    )
  ];
  Vec.S(1/m[3][3],u,u);
  return u;
}

// Return transformed normal
Mtx.transNormal = function(m,v) {
  const out = [0, 0, 0];
  let orig  = [0, 0, 0];
  let t1    = [1, 0, 0];
  let t2    = [0, 0, 0];
  Vec.Normalize(v);
  // Create a t1 vector not aligned with in
  const dot = Vec.Dot(t1, v);
  if (Vec.ABS(dot) > 0.8) {
    Vec.Make(0.0, 1.0, 0.0, t1);
  }
  Vec.Cross(v, t1, t2);   // Create t2
  Vec.Cross(t2, v, t1);   // Create proper t1
  // Transform tangents
  t1 = Mtx.transVector(m, t1);
  t2 = Mtx.transVector(m, t2);
  orig = Mtx.transVector(m, orig);
  Vec.Sub(t1, orig, t1);
  Vec.Sub(t2, orig, t2);
  Vec.Cross(t1, t2, out);  // Recreate normal
  return out;
}

// Compose vector as text
Mtx.composeVector = function(name,v) {
  name=name?name:'vector';
  v = Vec.fix(v);
  const s = `${name} ${v[0]} ${v[1]} ${v[2]}`;
  return s;
}

// Compose matrix as text
Mtx.composeMatrix = function(name,m) {
  name=name?name:'matrix';
  const s = `${name}\n`;
  const x = `${m[0][0]} ${m[0][1]} ${m[0][2]} ${m[0][3]}\n`;
  const y = `${m[1][0]} ${m[1][1]} ${m[1][2]} ${m[1][3]}\n`;
  const z = `${m[2][0]} ${m[2][1]} ${m[2][2]} ${m[2][3]}\n`;
  const w = `${m[3][0]} ${m[3][1]} ${m[3][2]} ${m[3][3]}`;
  return (s+x+y+z+w);
}

// Compose translation as text
Mtx.composeTranslate = function(tx,ty,tz) {
  return (Mtx.composeVector('translate',[tx,ty,tz]));
}

// Compose scale transform as text
Mtx.composeScale = function(sx,sy,sz) {
  return (Mtx.composeVector('scale',[sx,sy,sz]));
}

// Compose x rotate transform as text
Mtx.composeRotateX = function(angle) {
  return (Mtx.composeVector('rotate',[angle,0,0]));
}

// Compose y rotate transform as text
Mtx.composeRotateY = function(angle) {
  return (Mtx.composeVector('rotate',[0,angle,0]));
}

// Compose z rotate transform as text
Mtx.composeRotateZ = function(angle) {
  return (Mtx.composeVector('rotate',[0,0,angle]));
}

// Compose x,y,z rotate transform as text
Mtx.composeRotate = function(rx,ry,rz) {
  return (Mtx.composeVector('rotate',[rx,ry,rz]));
}

// Report matrix state to callback
Mtx.report = function(name,m,callback) {
  if ('function' === typeof callback) {
    callback(Mtx.composeMatrix(name,m));
  }
  else {
    console.log(Mtx.composeMatrix(name,m));
  }
}

