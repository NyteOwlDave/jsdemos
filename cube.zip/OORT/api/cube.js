
/*

  cube.js -- 3D cube class
  Dave Wellsted, NyteOwl Computer Software
  2017-DEC-31
  
*/

const Cube = {
  view: [],     // View coordinates
  vert: [],     // Object coordinates
  face: [],     // Face definitions
  color: [      // Face colors
    'white', 'blue', 'yellow',
    'green', 'red', 'cyan'
  ],
  // Center point
  center: [0,0,0],
  // Rotations (degrees)
  rotX: 10,
  rotY: 20,
  rotZ: 5,
  // Transform matrix
  matrix: Mtx.identity(),
  // Initialize
  init: function(size,center) {
    const N = -0.5*size;
    const P =  0.5*size;
    Cube.vert[0] = [N,P,N]; 
    Cube.vert[1] = [P,P,N]; 
    Cube.vert[2] = [P,N,N]; 
    Cube.vert[3] = [N,N,N]; 
    Cube.vert[4] = [P,P,P]; 
    Cube.vert[5] = [N,P,P]; 
    Cube.vert[6] = [N,N,P]; 
    Cube.vert[7] = [P,N,P];
    Cube.face[0] = [1,0,3,2];
    Cube.face[1] = [2,3,6,7];
    Cube.face[2] = [7,6,5,4];
    Cube.face[3] = [4,5,0,1];
    Cube.face[4] = [0,5,6,3];
    Cube.face[5] = [4,1,2,7];
    Vec.Copy(center,Cube.center);
  },
  // Get one face as a 2D polygon
  // handles perspective correction
  getFacePolygon: function(n) {
    const poly = [];
    const face = Cube.face[n];
    face.forEach(index=>{
      let vec3 = [
        Cube.view[index][0],
        Cube.view[index][1],
        Cube.view[index][2]
      ];
      poly.push(Screen.mapToScreen(vec3));
    });
    return poly;
  },
  // Draw the cube
  drawCube: function(canvas) {
    const nMax = Cube.face.length;
    let n;
    // For each face
    for (n=0; n<nMax; n++) {
      // Get a 2D polygon for the face
      let p = Cube.getFacePolygon(n);
      // If polygon faces the viewpoint
      if (Cube.getNormalZ(p)<0) {
        // Draw it filled
        Grafix.fillPolygon2(
          canvas,
          p,
          Cube.color[n]
        );
      }
    }
  },
  // Calculate polygon z-normal
  getNormalZ: function(p) {
    // Calculates only the Z component of the
    // plane normal for the polygon (for hidden
    // surface removal)
    const xa = p[1].x-p[0].x;
    const ya = p[1].y-p[0].y;
    const xb = p[2].x-p[0].x;
    const yb = p[2].y-p[0].y;
    return ((xa*yb)-(ya*xb));
  },
  // Transform vertices from object to view space
  transformVerts: function() {
    const nMax = Cube.vert.length;
    let n;
    for (n=0; n<nMax; n++) {
      Cube.view[n] = Mtx.transVector(Cube.matrix,Cube.vert[n]);
    }
  },
  // Update the view matrix
  updateMatrix: function() {
    const A = Mtx.rotate(
      Vec.deg2rad(Cube.rotX), 
      Vec.deg2rad(Cube.rotY), 
      Vec.deg2rad(Cube.rotZ)
    );
    const B = Mtx.translate(
      Cube.center[0],
      Cube.center[1],
      Cube.center[2]
    );
    Cube.matrix = Mtx.cat(B,A);
  }
}

