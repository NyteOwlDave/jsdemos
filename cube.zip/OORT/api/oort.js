
/*

  oort.js
  Object Oriented Ray Tracing stuff
  Dave Wellsted, NyteOwl Computer Software
  2017-DEC-31

*/

const OORT = {
   // Draw cross hatch marks
  crossHatch: function(p,b,d,dist) {
    OORT.hatch(p,b,d,dist);
    const t = d.x;
    d.x = -d.y;
    d.y = t;
    OORT.hatch(p,b,d,dist);
  },
  // Draw single hatch marks
  // p    polygon vertex array
  // b    anchor point
  // d    direction vector
  // dist distance between lines
  hatch: function(p,b,d,dist) {
    let i,isec,j,lasti,n,nmin,nmax
    let nint,nnp,npoint=[],m=p.length
    let alpha,c,cmax,cmid,cmin,dmod
    let mu1,mu2,mu=[]
    let e={},inter={},p1={},p2={},q={},s={}
    const gfx = idCanvas.getContext('2d')
    gfx.strokeStyle='white';
    // Find cmin, cmid and cmax
    cmid=d.x*b.y - d.y*b.x;
    cmin= Constants.HUGE;
    cmax=-Constants.HUGE;
    for (i=0; i<m; i++) {
      c=d.x*p[i].y - d.y*p[i].x;
      if (c<cmin) cmin=c;
      if (c>cmax) cmax=c;
    }
    // Construct vector s
    dmod=d.length();
    s.x=-dist/dmod*d.y;
    s.y= dist/dmod*d.x;
    // Calculate nmin and nmax
    nmin=Math.floor((cmin-cmid)/(dist*dmod)+0.9999);
    nmax=Math.floor((cmax-cmid)/(dist*dmod));
    // Hatch the polygon
    for (n=nmin; n<=nmax; n++) {
      // Find base vector q for this line
      q.x=b.x+n*s.x;
      q.y=b.y+n*s.y;
      // Find nint (intersection)
      nint=0; lasti=m-1;
      for (i=0; i<m; i++) {
        e.x=p[i].x - p[lasti].x;
        e.y=p[i].y - p[lasti].y;
        isec = OORT.ill2(p[lasti],e,q,d,inter);
        if (isec) {
          alpha=(inter.x-p[lasti].x)/e.x;
          if ((alpha>=0)&&(alpha<=1)) {
            nint=nint+1;
            npoint[nint]=nint;
            mu[nint]=(inter.x-q.x)/d.x;
          }
        }
        lasti=i;
      }
      // Sort mu values
      for (i=1; i<nint; i++) {
        for (j=i+1; j<=nint; j++) {
          if (mu[npoint[i]] < mu[npoint[j]]) {
            nnp=npoint[i];
            npoint[i]=npoint[j];
            npoint[j]=nnp;
          }
        }
      }
      // Draw hatch lines
      gfx.beginPath();
      i=1;
      while (i<nint) {
        mu1=mu[npoint[i]];
        mu2=mu[npoint[i+1]];
        p1.x=q.x+mu1*d.x; p1.y=q.y+mu1*d.y;
        p2.x=q.x+mu2*d.x; p2.y=q.y+mu2*d.y;
        gfx.moveTo(p1.x,p1.y);
        gfx.lineTo(p2.x,p2.y);
        gfx.stroke();
        i+=2;
      }
    }
  },
  // Find POI (in v) for two lines
  // v1+mu*v2 and v3+lambda*v4
  // Returns true for success
  ill2: function(v1,v2,v3,v4,v) {
    let mu, delta;
    delta=v2.x*v4.y-v2.y*v4.x;
    if (Math.abs(delta)<Constants.TINY) {
      return false; // Lines are parallel
    }
    mu=((v3.x-v1.x)*v4.y-((v3.y-v1.y)*v4.x))/delta;
    v.x=v1.x+mu*v2.x;
    v.y=v1.y+mu*v2.y;
    return true;
  },
  // Algebraic sign [-1,0,+1]
  sign: function(r) {
    if (r > Constants.TINY) {
      return 1;
    }
    if (r < -Constants.TINY) {
      return -1;
    }
    return 0;
  },
  // Determine polygon orientation
  // p0, p1, p2 -- polygon vertices
  // Returns:
  // +1 for CW
  // -1 for CCW
  // 0 for degenerate
  orient2: function(p0,p1,p2) {
    const d1 = {}, d2 = {}
    d1.x=p1.x-p0.x; d1.y=p1.y-p0.y;
    d2.x=p2.x-p1.x; d2.y=p2.y-p1.y;
    return OORT.sign(d1.x*d2.y-d1.y*d2.x);
  },
  // Intersection of two polygons
  // Clips polygon a to polygon b, resulting in c.
  // Returns false for no intersection (fully clipped).
  // Orientation is as from orient2 on both a AND b.
  overlap: function(apoly,bpoly,cpoly,orientation) {
    let numa = apoly.length;
    let numb = bpoly.length;
    let numc;
    let i, j, index1, index2, l1, l2, cnumdash;
    const f = [[],[]];
    let end1 = {}, end2 = {}, v1 = {}, v2 = {};
    let ca, cb, cc, fv1, fv2, absfv1, absfv2, delta;
    // Copy apoly into f[0] array
    l1=0; numc=numa;
    for (i=0; i<numc; i++) {
      f[l1][i] = Vector2Factory.createFrom(apoly[i]);
    }
    // Clip feasible poly. End points are end1, end2.
    end1 = bpoly[numb-1];
    for (i=0; i<numb; i++) {
      l2 = 1-l1;
      end2 = bpoly[i];
      ca = end2.x - end1.x;
      cb = end1.y - end2.y;
      cc = -end1.x*cb - end1.y*ca;
      v1 = Vector2Factory.createFrom(f[l1][numc-1]);
      fv1 = ca*v1.y + cb*v1.x + cc
      absfv1 = Math.abs(fv1);
      if (absfv1 < Constants.TINY) {
        index1 = 0;
      }
      else {
        index1 = OORT.sign(fv1) * orientation;
        numcdash = 0;
        for (j=0; j<numc; j++) {
          v2 = Vector2Factory.createFrom(f[l1][j]);
          fv2 = ca*v2.y + cb*v2.x + cc;
          absfv2 = Math.abs(fv2);
          if (absfv2 < Constants.TINY) {
            index2 = 0;
          }
          else {
            index2 = OORT.sign(fv2) * orientation;
          }
          if (index1 >= 0) {
            f[l2][numcdash] = v1;
            numcdash = numcdash + 1;
          }
          if ((index1!==0) && (index1!==index2) && (index2!==0)) {
            delta = absfv1 + absfv2;
            f[l2][numcdash] = {}
            f[l2][numcdash].x = (absfv2*v1.x + absfv1*v2.x)/delta;
            f[l2][numcdash].y = (absfv2*v1.y + absfv1*v2.y)/delta;
            numcdash = numcdash + 1;
          }
          fv1 = fv2;
          absfv1 = absfv2;
          index1 = index2;
          v1 = v2;
        }
        if (numcdash<3) {
          return false; // degenerate
        }
        else {
          numc = numcdash;
          l1 = l2;
          end1 = end2;
        }
      }
    }
    // Copy resulting polygon to o/p
    for (i=0; i<numc; i++) {
      cpoly[i] = Vector2Factory.createFrom(f[l1][i]);
    }
    return true;
  }
}
