
/*
  vector2.js
  2D vector functionality
  Dave Wellsted, NyteOwl Computer Software
  2018-JAN-03

  Constants:
  
    HUGE, TINY
    D2R, R2D, 
    SQR2, SQR2INV, SQR3, SQR3INV
  
  Scalar functions:
  
    deg2rad, rad2deg
  
  Polar properties:
  
    rho, theta
  
  Polar methods:
    
    real, imag, toVector
  
  Cartesian properties:
  
    x, y
  
  Cartesian methods:
  
    selfDot, length, angle, toPolar, inverseLength
    normalize, approxNormal, dot, perp, dydx, dxdy
    dydt, dxdt, plu, minus, times, discretePerp
    toArray, fromArray, toMatrix, scaleby, pythag
    normal, normalize, project, combine
    direction, distance. clone
    
*/

// Constants
const Constants = {
  HUGE    : 1e+8,
  TINY    : 1e-8,
  D2R     : Math.PI/180,
  R2D     : 180/Math.PI,
  SQR2    : Math.sqrt(2),
  SQR2INV : 1/Math.sqrt(2),
  SQR3    : Math.sqrt(3),
  SQR3INV : 1/Math.sqrt(3)
};

// Convert degrees to radians
const deg2rad = function(r) {
  return r*Constants.D2R;
}

// Convert radians to degrees
const rad2deg = function(d) {
  return d*Constants.R2D;
}

// Vector 2 in polar form
function Polar2(rho,theta) {
  // Radius
  this.rho = rho;
  // Angle
  this.theta = theta;
  // Complex real number
  this.real = function() {
    return this.rho * Math.cos(this.theta);
  }
  // Complex imaginary number
  this.imag = function() {
    return this.rho * Math.sin(this.theta);
  }
  // Return equivalent vector in cartesian form
  this.toVector = function() {
    return new Vector2(this.real(), this.imag());
  }
  return this;
}

// Vector 2 in cartesian form
function Vector2(x,y) {
  // Maximum squared length
  const maxLenSqr = 1e+20;
  // Minimum squared length
  const minLenSqr = 1e-20;
  let xx = Number(x);
  let yy = Number(y);
  // Calculate squared length
  let lenSqr = xx*xx+yy*yy;
  // Check for NaN
  if (isNaN(lenSqr)) {
    this.x = 0;
    this.y = 0;
    throw 'Invalid argument!';
  }
  // Check for range error
  if ((lenSqr>maxLenSqr)||(lenSqr<minLenSqr)) {
    this.x = 0;
    this.y = 0;
    throw 'Vector range error!';
  }
  // Initialize values
  this.x = xx;
  this.y = yy;
  // Dot product with self (length squared)
  this.selfDot = function() {
    return (this.x*this.x+this.y*this.y);
  }
  // Calculate vector length
  this.length = function() {
    return Math.hypot(this.x,this.y);
  }
  // Calculate vector angle
  this.angle = function() {
    return Math.atan2(y,x);
  }
  // Return equivalent polar vector
  this.toPolar = function() {
    return new Polar2(this.length(), this.angle());
  }
  // Calculate reciprocal of vector length
  this.inverseLength = function() {
    return (1 / this.length());
  }
  // Determine if vector is approximately normal
  this.approxNormal = function() {
    return (Math.abs(1-this.selfDot())<minLenSqr);
  }
  // Dot product of two vectors
  this.dot = function(vec) {
    return (this.x*vec.x+this.y*vec.y);
  }
  // Perp-dot product of two vectors
  this.perp = function(vec) {
    return (this.x*vec.y-this.y*vec.x);
  }
  // Rate of change of y with respect to x
  this.dydx = function() {
    return (this.y / this.x);
  }
  // Rate of change of x with respect to y
  this.dxdy = function() {
    return (this.x / this.y);
  }
  // Rate of change of y with respect to time
  this.dydt = function() {
    return (this.y * this.inverseLength());
  }
  // Rate of change of x with respect to time
  this.dxdt = function() {
    return (this.x * this.inverseLength());
  }
  // Elementwise vector addition
  this.plus = function(vec) {
    return new Vector2(this.x+vec.x, this.y+vec.y);
  }
  // Elementwise vector subtraction
  this.minus = function(vec) {
    return new Vector2(this.x-vec.x, this.y-vec.y);
  }
  // Elementwise vector multiplication
  this.times = function(vec) {
    return new Vector2(this.x*vec.x, this.y*vec.y);
  }
  // Calculate discrete elements of perp-dot
  this.discretePerp = function(vec) {
    return [this.x*vec.y, -this.y*vec.x];
  }
  // Convert to array
  this.toArray = function() {
    return [this.x, this.y];
  }
  // Convert from array
  this.fromArray = function(array) {
    this.x = Number(array[0]);
    this.y = Number(array[1]);
    return this;
  }
  // Calculate transformation matrix
  this.toMatrix = function(vec) {
    return [
      [this.x*vec.x,  -this.y*vec.x],
      [this.x*vec.y,   this.y*vec.y]
    ];
  }
  // Scale this vector by the given amount
  this.scaleby = function(scalar) {
    this.x *= scalar;
    this.y *= scalar;
    return this;
  }
  // Return an array containing [x*x, y*y, z*z]
  this.pythag = function() {
    let xsqr = this.x*this.x;
    let ysqr = this.y*this.y;
    let zsqr = xsqr + ysqr;
    return [xsqr,ysqr,zsqr];
  }
  // Return the unit normal vector
  this.normal = function() {
    let lenSqr = this.selfDot();
    let scale = 1 / Math.sqrt(lenSqr);
    return new Vector2(this.x*scale, this.y*scale);
  }
  // Normalize and return prior length
  this.normalize = function() {
    let lenSqr = this.selfDot();
    if (lenSqr > Constants.TINY) {
      let len = Math.sqrt(lenSqr);
      let scale = 1 / len;
      this.x *= scale;
      this.y *= scale;
      return len;
    }
    else {
      this.x = 1;
      this.y = 0;
      return 1;
    }
  }
  // Project a ray from this point
  // given:
  //    direction vector (unit length)
  //    distance
  this.project = function(direction,dist) {
    let x = this.x + direction.x * dist;
    let y = this.y + direction.y * dist;
    return new Vector2(x, y);
  }
  // Unit direction vector from this point to another
  this.direction = function(point) {
    let dx = point.x - this.x;
    let dy = point.y - this.y;
    let lenSqr = dx*dx+dy*dy;
    let scale = 1 / Math.sqrt(lenSqr);
    return new Vector2(dx*scale, dy*scale);
  }
  // Distance from this point to another
  this.distance = function(point) {
    let dx = point.x - this.x;
    let dy = point.y - this.y;
    return Math.sqrt(dx*dx+dy*dy);
  }
  // Combine two scaled vectors
  this.combine = function(A,a,B,b) {
    this.x = A*a.x + B*b.x;
    this.y = A*a.y + B*b.y;
    return this;
  }
  // Clone vector
  this.clone = function() {
    return new Vector2(this.x, this.y)
  }
  return this;
}

// Factory for Vector2 objects
const Vector2Factory = {
  // Create from discrete components
  create: function(x,y) {
    return new Vector2(x,y);
  },
  // Create from another object having x and y members
  createFrom: function(obj) {
    return new Vector2(obj.x, obj.y);
  }
}

