
/*

  grafix.js -- graphics functions
  Dave Wellsted, NyteOwl Computer Software
  2017-DEC-30
  
*/

// Project.register('grafix.js')

const Grafix = {
  // Fill canvas will a color
  fill: function(canvas,color) {
    const w = canvas.width
    const h = canvas.height
    const gfx = canvas.getContext('2d')
    gfx.fillStyle = color
    gfx.fillRect(0,0,w,h)
  },
  // Draw a spiderweb (circular graph)
  spider: function(canvas,color,stepSize) {
    const w = canvas.width
    const h = canvas.height
    const xc = w/2
    const yc = h/2
    const gfx = canvas.getContext('2d')
    gfx.strokeStyle = color
    const rho = 0.5 * Math.sqrt(w*w + h*h)
    function line(n) {
      if (n < 0) return
      const theta = n*Math.PI/12
      const dx = rho*Math.cos(theta)
      const dy = rho*Math.sin(theta)
      gfx.beginPath()
      gfx.moveTo(xc+dx,yc+dy)
      gfx.lineTo(xc-dx,yc-dy)
      gfx.stroke()
      line(n-1)
    }
    line(11)
    function circle(n) {
      if (n < 1) return
      const r = n*stepSize
      gfx.beginPath()
      gfx.ellipse(xc,yc,r,r,0,0,2*Math.PI)
      gfx.stroke()
      circle(n-1)
    }
    circle(Math.floor(rho/stepSize))
  },
  // Draw the polygon whose vertices
  // are stored in array p
  drawPolygon: function(canvas,p) {
    const gfx = canvas.getContext('2d');
    gfx.strokeStyle = 'white';
    gfx.lineWidth = 1;
    gfx.beginPath();
    const n = p.length-1;
    let i,j;
    for (i=1; i<=n; i++) {
      j = i-1;
      gfx.moveTo(p[j].x,p[j].y);
      gfx.lineTo(p[i].x,p[i].y);
      gfx.stroke();
    }
    j = n;
    i = 0;
    gfx.moveTo(p[j].x,p[j].y);
    gfx.lineTo(p[i].x,p[i].y);
    gfx.stroke();
  }
}

